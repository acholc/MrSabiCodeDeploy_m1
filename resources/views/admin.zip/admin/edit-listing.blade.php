@extends('admin.master')
@section('body')
<main class="main-wrapper clearfix">
   <!-- Page Title Area -->
   <div class="page-title">
      <div class="container">
         <div class="row">
            <div class="page-title-left">
               <h6 class="page-title-heading mr-0 mr-r-5">Edit Listing</h6>
            </div>
            <!-- /.page-title-left -->
            <div class="page-title-right d-none d-sm-inline-flex align-items-center">
               <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="{{route('adm.admin')}}">Home</a>
                  </li>
                  <li class="breadcrumb-item"><a href="{{route('adm.listing')}}">Business Listing</a>
                  </li>
                  <li class="breadcrumb-item active">Edit Listing</li>
               </ol>
            </div>
            <!-- /.page-title-right -->
         </div>
         <!-- /.row -->
      </div>
      <!-- /.container -->
   </div>
   <!-- /.page-title -->
   <!-- =================================== -->
   <div class="container">
      <div class="row">
         <!-- Default Tabs -->
         <div class="col-md-12 widget-holder">
		 
		
                                    
                                    <!-- /.modal -->
                                   
		 
            <div class="widget-bg">
               <div class="widget-body">
                  
                  <div class="tabs edit_list_tabs">
                     <ul class="nav nav-tabs">
                        <li class="nav-item"><a class="nav-link active" href="#basic_info" data-toggle="tab" aria-expanded="true">Basic Info</a>
                        </li>
                        <li class="nav-item"><a class="nav-link" href="#ratings" data-toggle="tab" aria-expanded="true">Ratings</a>
                        </li>
                     </ul>
                     <!-- /.nav-tabs -->
                     <div class="tab-content">
                        <div class="tab-pane active" id="basic_info">
                           <div class="row">
                              <div class="col-md-12 p-0">
                                 <div class="widget-bg">
                                    <div class="widget-heading clearfix">
                                       <h5>Edit Listing</h5>
                                    </div>
                                    <!-- /.widget-heading -->
                                    <div class="widget-body clearfix">
                                       <form id="profile_changes" action="javascript:void(0)">
                                          {{ csrf_field()}}
                                          <div class="row">
                                             <div class="col-md-12">
                                                <div class="row">
                                                   <div class="col-lg-12">
                                                      <div class="form-group">
                                                         <label for="l30">Created By</label>
                                                         <input class="form-control"  value="{{$data[0]->user[0]['name']}}" type="text" value="The Tipsy Cow, Madison, WI" name="name" >
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="row">
                                                   <div class="col-lg-6">
                                                      <div class="form-group">
                                                         <label for="l30">Business Name</label>
                                                         <input class="form-control"  value="{{$data[0]->title}}" type="text" value="The Tipsy Cow, Madison, WI" name="name" >
                                                      </div>
                                                   </div>
                                                   <div class="col-lg-6">
                                                      <div class="form-group">
                                                         <label for="l30">Categories</label>
                                                         <select class="livesearch form-control">
                                                             @foreach($data[0]->categories as $key)
                                                            <option value="{{$key['id']}}" <?php echo ($data[0]->category_id ==$key['id'])?"selected":"" ?>>{{$key['category']}}</option>
                                                            @endforeach
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="row">
                                                   <div class="col-lg-12">
                                                      <div class="form-group">
                                                         <div class="form-group tag_input">
                                                            <label class="control-label">Tags</label>
                                                            <input type="text" value="{{$data[0]->tags}}" data-role="tagsinput" placeholder="Tags" class="form-control"/>
                                                         </div>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="row">
                                                   <div class="col-lg-12">
                                                      <div class="form-group">
                                                         <label for="exampleInputEmail1">Description</label>
                                                         <textarea type="text" class="form-control" rows="6" placeholder="">{{$data[0]->description}}</textarea>
                                                      </div>
                                                   </div>
                                                </div>
                                                @foreach($data[0]->days_time as $key)
                                                <div class="form-table"  id="customFields">
                                                   <div class="row customFields">
                                                      <div class='col-md-4'>
                                                         <div class="form-group">
                                                            <select class="form-control">
                                                                    <option <?php echo ($key['day'] == 'Monday')?"selected":"" ?>>Monday</option>
                                                                    <option <?php echo ($key['day'] == 'Tuesday')?"selected":"" ?>>Tuesday</option>
                                                                    <option <?php echo ($key['day'] == 'Wednesday')?"selected":"" ?>>Wednesday</option>
                                                                    <option <?php echo ($key['day'] == 'Thursday')?"selected":"" ?>>Thursday</option>
                                                                    <option <?php echo ($key['day'] == 'Friday')?"selected":"" ?>>Friday</option>
                                                                    <option <?php echo ($key['day'] == 'Saturday')?"selected":"" ?>>Saturday</option>
                                                                    <option <?php echo ($key['day'] == 'Sunday')?"selected":"" ?>>Sunday</option>
                                                            </select>
                                                         </div>
                                                      </div>
                                                      <div class='col-md-3'>
                                                         <div class="form-group">
                                                            <div class='input-group'>
                                                               <input type='text' class="form-control input-group date timepicker" placeholder="Opening Hour" name="opening_hour[]" value="{{$key['opening_hour']}}"/>
                                                               <span class="input-group-addon">
                                                               <span class="fa fa-clock-o"></span>
                                                               </span>
                                                            </div>
                                                         </div>
                                                      </div>
                                                      <div class='col-md-3'>
                                                         <div class="form-group">
                                                            <div class='input-group' id='timepicker2'>
                                                               <input type='text' class="form-control input-group date timepicker" placeholder="Closing Hour" name="closing_hour[]" value="{{$key['closing_hour']}}"/>
                                                               <span class="input-group-addon">
                                                               <span class="fa fa-clock-o"></span>
                                                               </span>
                                                            </div>
                                                         </div>
                                                      </div>
                                                      <div class='col-md-2'>
                                                         <div class="form-group">
                                                            <a href="javascript:void(0);" class="btn add-row addCF"><i class="fa fa-minus"></i></a>
                                                         </div>
                                                      </div>
                                                   </div>
                                                </div>
                                                @endforeach
                                                <!--///-->
                                                         <div class="form-table"  id="customFields">
                                                   <div class="row customFields">
                                                   <div class='col-md-2'>
                                                         <div class="form-group">
                                                            <a href="javascript:void(0);" class="btn add-row addCF"><i class="fa fa-plus"></i></a>
                                                         </div>
                                                      </div>
                                                                   </div>
                                                </div>
                                                <!--///-->
                                                <h4 class="dobl-brdr mt-2">Contact Information</h4>
                                                <div class="row">
                                                   <div class="col-lg-6">
                                                      <div class="form-group">
                                                         <label for="l30">Address</label>
                                                         <input class="form-control"  value="{{$data[0]->address}}" type="text" id="autocomplete">
                                                      </div>
                                                   </div>
                                                   <div class="col-lg-6">
                                                      <div class="form-group">
                                                         <label for="l30">City</label>
                                                         <input class="form-control"  value="{{$data[0]->city}}" type="text">
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="row">
                                                   <div class="col-lg-6">
                                                      <div class="form-group">
                                                         <label for="l30">State</label>
                                                         <select class="livesearch form-control">
                                                             
                                                             @foreach($data[0]->states as $key)
                                                            <option value="{{$key['state_id']}}}" <?php echo ($key['state_id'] == $data[0]->state_id)?"selected":"" ?>>{{$key['state_name']}}</option>
                                                            @endforeach
                                                          
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="col-lg-6">
                                                      <div class="form-group">
                                                         <label for="l30">Phone No</label>
                                                         <input class="form-control"  value="{{$data[0]->phone}}" type="text">
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="row">
                                                   <div class="col-lg-6">
                                                      <div class="form-group">
                                                         <label for="l30">Email</label>
                                                         <input class="form-control"  value="{{$data[0]->mail}}" type="text">
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="col-lg-6">
                                                      <div class="form-group">
                                                         <label for="l30">Website</label>
                                                         <input class="form-control"  value="{{$data[0]->website}}" type="text">
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="row">
                                                   <div class="col-lg-12">
                                                              <div id="map" class="map-container">
                                                               </div>
                                                   </div>
                                                </div>
                                                <div class="row preview-images-zone mt-3">
                                                    @foreach($data[0]->images as $key)
                                                   <div class="col-lg-3 preview-image preview-show-1">
                                                      <div class="image-cancel" data-no="1">x</div>
                                                      <div class="image-zone"><img id="pro-img-1" src="{{url('public/images')}}/{{$key['name']}}"></div>
                                                   </div>
                                                   @endforeach
                                               
                                                </div>
                                                <div class="row">
                                                   <div class="col-lg-12">
                                                      <a href="javascript:void(0)" onclick="$('#pro-image').click()" class="drop_files">Click here to upload files</a>
                                                      <input type="file" id="pro-image" name="pro-image" style="display: none;" class="form-control" multiple>
                                                   </div>
                                                </div>
                                                <div class="row">
                                                   <div class="col-lg-12 mt-3">
                                                      <div class="form-actions btn-list">
                                                         <button class="btn btn-primary" type="submit">Save Changes</button>
                                                         <a href="{{route('adm.users')}}" class="btn btn-warning">Cancel</a>
                                                         <span id="pass-error" class="text-danger"></span>
                                                      </div>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                       </form>
                                    </div>
                                    <!-- /.widget-body -->
                                 </div>
                                 <!-- /.widget-bg -->
                              </div>
                           </div>
                        </div>
                        <div class="tab-pane" id="ratings">
                           <div class="row">
                              <div class="col-md-12 p-0">
                                 <div class="widget-bg">
                                    <div class="widget-heading clearfix">
                                       <h5>Users Ratings
                                       <a href="" data-toggle="modal" data-target=".add_rating" class="float-right btn btn-warning  btn-sm"><i class="fa fa-plus"></i> &nbsp; Add New </a>
                                       </h5>
            
                                    </div>
                                    <!-- /.widget-heading -->
                                    <div class="widget-body clearfix">
										
                                       <div class="table-responsive">
                                          <table class="table table-striped" data-toggle="datatables" data-plugin-options='{"searching": false}'>
                                             <thead>
                                                <tr>
                                                   <th>Image</th>
                                                   <th>Name</th>
												   <th>Ratings</th>	
                                                   <th>Comment</th>
                                                   <th>Action</th>
                                                </tr>
                                             </thead>
                                             <tbody>
                                                  @foreach($data[0]['rating'] as $key)
                                                  <tr id="user_row">
                                                      @if($key['userdata']['profile_image'] && file_exists('public/images/'.$key['userdata']['profile_image']))
                                                   <td style="min-width:40px;"><img src="{{URL('public/images')}}/{{$key['name']}}" class="user_profile"></td>
                                                   @else  <img src="{{URL('public/images/default-small.jpg')}}" alt="" />
                                                   @endif
                                                   <td>user singh</td>
												   <td><div class="rating-score"><a href="#"><i class="fa fa-star"></i></a>
												<a href="#"><i class="fa fa-star"></i></a>
												<a href="#"><i class="fa fa-star"></i></a>
												<a href="#"><i class="fa fa-star"></i></a>
												<a href="#"><i class="fa fa-star-half-o"></i></a></div></td>
                                                   <td>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam tincidunt lectus sed sem lobortis, a hendrerit libero sodales. Cras at interdum lacus, in imperdiet sem.</td>
                                                   <!-- <td><label class="badge badge-success">Active</label></td> -->
                                                   <td>
                                                      <a href="#"  data-toggle="modal" data-target=".bs-modal-md" class="btn btn-primary btn-circle btn-sm ripple">
                                                      <i data-toggle="tooltip" title="Edit" class="list-icon lnr lnr-pencil"></i>
                                                      </a>
                                                      <a href="javascript:void(0)" class="btn btn-warning btn-circle btn-sm ripple" data-toggle="modal" data-target=".delete-pop">
                                                      <i data-toggle="tooltip" data-placement="top" title="Delete" class="list-icon lnr lnr-trash" id="31"></i>
                                                      </a>
                                                   </td>
                                                </tr>
                                               @endforeach
                                       
                                             </tbody>
                                          </table>
                                       </div>
                                    </div>
                                    <!-- /.widget-body -->
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <!-- /.tab-content -->
                  </div>
                  <!-- /.tabs -->
               </div>
               <!-- /.widget-body -->
            </div>
            <!-- /.widget-bg -->
         </div>
         <!-- /.widget-holder -->
      </div>
   </div>
   <!-- /.container -->
   <div class="modal fade bs-modal-md" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none">
                                        <div class="modal-dialog modal-md">
                                            <div class="modal-content">
                                               
                                                <div class="modal-body">
													<form>
										<div class="form-group">
                                            <label for="l38">Edit Ratings</label>
                                            <div class="edit-rating">
												<a href="#"><i class="fa fa-star"></i></a>
												<a href="#"><i class="fa fa-star"></i></a>
												<a href="#"><i class="fa fa-star"></i></a>
												<a href="#"><i class="fa fa-star"></i></a>
												<a href="#"><i class="fa fa-star"></i></a></div>
                                        </div>
                                        <div class="form-group">
                                            <label for="l38">Edit Comment</label>
                                            <textarea class="form-control" id="l38" rows="3">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam tincidunt lectus sed sem lobortis, a hendrerit libero sodales. Cras at interdum lacus, in imperdiet sem.</textarea>
                                        </div>
										
                                        
                                      
                                   	
                                                </div>
                                                <div class="modal-footer">
												<button class="btn btn-primary btn-sts btn-rounded ripple text-left" type="button">Save Changes</button>
                                            <button class="btn btn-danger btn-sts btn-rounded ripple text-left" data-dismiss="modal" aria-hidden="true" type="button">Cancel</button>
											 </form>
                                                </div>
                                            </div>
                                            <!-- /.modal-content -->
                                        </div>
                                        <!-- /.modal-dialog -->
                                    </div>
                                    
                                    
<div class="modal fade add_rating" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none">
                                        <div class="modal-dialog modal-md">
                                            <div class="modal-content">
                                               
                                                <div class="modal-body">
													<form>
										<div class="form-group">
                                            <label for="l38">Add Ratings</label>
                                            <div class="edit-rating">
												<a href="#"><i class="fa fa-star"></i></a>
												<a href="#"><i class="fa fa-star"></i></a>
												<a href="#"><i class="fa fa-star"></i></a>
												<a href="#"><i class="fa fa-star"></i></a>
												<a href="#"><i class="fa fa-star"></i></a></div>
                                        </div>
                                        <div class="form-group">
                                            <label for="l38">Add Comment</label>
                                            <textarea class="form-control" id="l38" rows="3"></textarea>
                                        </div>
										
                                        
                                      
                                   	
                                                </div>
                                                <div class="modal-footer">
												<button class="btn btn-primary btn-sts btn-rounded ripple text-left" type="button">Save Changes</button>
                                            <button class="btn btn-danger btn-sts btn-rounded ripple text-left" data-dismiss="modal" aria-hidden="true" type="button">Cancel</button>
											 </form>
                                                </div>
                                            </div>
                                            <!-- /.modal-content -->
                                        </div>
                                        <!-- /.modal-dialog -->
                                    </div>

   
</main>
@endsection('body')
@section('script')
<script>
        var input = document.getElementById('autocomplete');
        var autocomplete = new google.maps.places.Autocomplete(input);
        google.maps.event.addListener(autocomplete, 'place_changed', function() { 
            var loc= $('#autocomplete').val();         
var geocoder = new google.maps.Geocoder(); // initialize google map object
var address = loc;
geocoder.geocode( { 'address': address}, function(results, status) {

if (status == google.maps.GeocoderStatus.OK) {
   var latitude = results[0].geometry.location.lat();
var longitude = results[0].geometry.location.lng();
var myCenter=new google.maps.LatLng(latitude,longitude);
      function initialize()
{
var mapProp = {
 center:myCenter,
 zoom:14,
 mapTypeId:google.maps.MapTypeId.ROADMAP
 };

var map=new google.maps.Map(document.getElementById("map"),mapProp);

var marker=new google.maps.Marker({
 position:myCenter,
 });

marker.setMap(map);
}
initialize();
// google.maps.event.addDomListener(window, 'load', initialize); 
   } 
});
         
           });

        </script>

        <script>

  var loc= $('#autocomplete').val();         
var geocoder = new google.maps.Geocoder(); // initialize google map object
var address = "{{$data[0]->address}}";
geocoder.geocode( { 'address': address}, function(results, status) {

if (status == google.maps.GeocoderStatus.OK) {
   var latitude = results[0].geometry.location.lat();
var longitude = results[0].geometry.location.lng();
var myCenter=new google.maps.LatLng(latitude,longitude);
      function initialize()
{
var mapProp = {
 center:myCenter,
 zoom:13,
 mapTypeId:google.maps.MapTypeId.ROADMAP
 };

var map=new google.maps.Map(document.getElementById("map"),mapProp);

var marker=new google.maps.Marker({
 position:myCenter,
 });

marker.setMap(map);
}

google.maps.event.addDomListener(window, 'load', initialize); 
   } 
});

////add day field
   $(document).ready(function(){
   	$(".addCF").click(function(){
   		
   		$("#customFields").append('<div class="customFields row"><div class="col-md-4"><div class="form-group"><select class="form-control"><option>Select Day</option><option>Monday</option><option>Tuesday</option><option>Wednesday</option><option>Thursday</option><option>Friday</option><option>Saturday</option><option>Sunday</option></select></div></div><div class="col-md-3"><div class="form-group"><div class="input-group"><input type="text" class="input-group date timepicker form-control" placeholder="Opening Hour" /><span class="input-group-addon"><span class="fa fa-clock-o"></span></span></div></div></div><div class="col-md-3"><div class="form-group"><div class="input-group"><input type="text" class="input-group date timepicker form-control" placeholder="Closing Hour" /><span class="input-group-addon"><span class="fa fa-clock-o"></span></span></div></div></div><div class="col-md-2"><div class="form-group"><a href="javascript:void(0);" class="btn add-row remCF"><i class="fa fa-minus"</a></div></div></div>');
   	 $('.timepicker').timepicker({
           defaultTime: false
     });
     $(".livesearch").chosen();
   
   	});
       $("#customFields").on('click','.remCF',function(){
           $(this).parent().parent().parent().remove();
       });
   });
 </script>
@endsection('script')
