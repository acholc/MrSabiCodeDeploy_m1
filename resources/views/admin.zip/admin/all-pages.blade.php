@extends('admin.master')
@section('body')
        <main class="main-wrapper clearfix">
            <!-- Page Title Area -->
            <div class="page-title">
                <div class="container">
                    <div class="row">
                        <div class="page-title-left">
                            <h6 class="page-title-heading mr-0 mr-r-5">Pages</h6>
                        </div>
                        <!-- /.page-title-left -->
                        <div class="page-title-right d-none d-sm-inline-flex align-items-center">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="{{route('adm.admin')}}">Home</a>
                                </li>
                                <li class="breadcrumb-item active">Pages</li>
                            </ol>
                        </div>
                        <!-- /.page-title-right -->
                    </div>
                    <!-- /.row -->
                </div>
                <!-- /.container -->
            </div>
            <!-- /.page-title -->
            <!-- =================================== -->
            <div class="container">
                <div class="row">
					<div class="col-md-12 widget-holder">
						<div class="widget-bg">
							<div class="widget-heading clearfix">
								<h5>Pages
								<a href="{{route('adm.add-page')}}" class="float-right btn btn-warning  btn-sm"><i class="fa fa-plus"></i> &nbsp; Add New </a>
								</h5>
							</div>
							<!-- /.widget-heading -->
							<div class="widget-body clearfix">
								<div class="table-responsive">
									<table class="table table-striped" data-toggle="datatables" data-plugin-options='{"searching": false}'>
										<thead>
											<tr>
												<th>Sr. No.</th>
												<th>Title</th>
												<th>Date</th>
												<th>Action</th>
											</tr>
										</thead>
										<tbody>				
																			
											<tr id="user_row">
												
												<td>1</td>
												<td>Home</td>
												<td>21/05/2019</td>
												<td>
																									
													<a href="{{route('adm.edit-page')}}" class="btn btn-primary btn-circle btn-sm ripple">
														<i data-toggle="tooltip" title="Edit" class="list-icon lnr lnr-pencil"></i>
													</a>
													<a href="javascript:void(0)" class="btn btn-warning btn-circle btn-sm ripple" data-toggle="modal" data-target=".delete-pop">
														<i data-toggle="tooltip" title="Delete" class="list-icon lnr lnr-trash" id="31"></i>
													</a>
												</td>
											</tr>
											
											<tr id="user_row">
												
												<td>2</td>
												<td>About Us</td>
												<td>21/05/2019</td>
												<td>
												<a href="{{route('adm.edit-page')}}" class="btn btn-primary btn-circle btn-sm ripple">
														<i data-toggle="tooltip" title="Edit" class="list-icon lnr lnr-pencil"></i>
													</a>
													<a href="javascript:void(0)" class="btn btn-warning btn-circle btn-sm ripple" data-toggle="modal" data-target=".delete-pop">
														<i data-toggle="tooltip" title="Delete" class="list-icon lnr lnr-trash" id="31"></i>
													</a>
												</td>
											</tr>
											
											<tr id="user_row">
												
												<td>3</td>
												<td>Contact Us</td>
												<td>21/05/2019</td>
												<td>
													<a href="{{route('adm.edit-page')}}" class="btn btn-primary btn-circle btn-sm ripple">
														<i data-toggle="tooltip" title="Edit" class="list-icon lnr lnr-pencil"></i>
													</a>
													<a href="javascript:void(0)" class="btn btn-warning btn-circle btn-sm ripple" data-toggle="modal" data-target=".delete-pop">
														<i data-toggle="tooltip" title="Delete" class="list-icon lnr lnr-trash" id="31"></i>
													</a>
												</td>
											</tr>
											
											<tr id="user_row">
												
												<td>4</td>
												<td>Privacy Policy</td>
												<td>21/05/2019</td>
												<td>
													<a href="{{route('adm.edit-page')}}" class="btn btn-primary btn-circle btn-sm ripple">
														<i data-toggle="tooltip" title="Edit" class="list-icon lnr lnr-pencil"></i>
													</a>
													<a href="javascript:void(0)" class="btn btn-warning btn-circle btn-sm ripple" data-toggle="modal" data-target=".delete-pop">
														<i data-toggle="tooltip" title="Delete" class="list-icon lnr lnr-trash" id="31"></i>
													</a>
												</td>
											</tr>
											<tr id="user_row">
												
												<td>5</td>
												<td>Terms Of Service</td>
												<td>21/05/2019</td>
												<td>
												<a href="{{route('adm.edit-page')}}" class="btn btn-primary btn-circle btn-sm ripple">
														<i data-toggle="tooltip" title="Edit" class="list-icon lnr lnr-pencil"></i>
													</a>
													<a href="javascript:void(0)" class="btn btn-warning btn-circle btn-sm ripple" data-toggle="modal" data-target=".delete-pop">
														<i data-toggle="tooltip" title="Delete" class="list-icon lnr lnr-trash" id="31"></i>
													</a>
												</td>
											</tr>						
										</tbody>
									</table>
								</div>
							</div>
							<!-- /.widget-body -->
						</div>
						<!-- /.widget-bg -->
					</div>
               </div>
            </div>

            <!-- /.container -->
        </main>
        <!-- /.main-wrappper -->
       
    </div>
    <!-- /.content-wrapper -->
@endsection('body')

