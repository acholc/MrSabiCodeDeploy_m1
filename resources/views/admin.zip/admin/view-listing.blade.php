@extends('admin.master')
@section('body')
        <main class="main-wrapper clearfix">
            <!-- Page Title Area -->
            <div class="page-title">
                <div class="container">
                    <div class="row">
                        <div class="page-title-left">
                            <h6 class="page-title-heading mr-0 mr-r-5">View Listing</h6>
                        </div>
                        <!-- /.page-title-left -->
                        <div class="page-title-right d-none d-sm-inline-flex align-items-center">
                            <ol class="breadcrumb">
                               <li class="breadcrumb-item"><a href="{{route('adm.admin')}}">Home</a>
                                </li>
								<li class="breadcrumb-item"><a href="{{route('adm.listing')}}">Business Listing</a>
                                </li>
                                <li class="breadcrumb-item active">View Listing</li>
                            </ol>
                        </div>
                        <!-- /.page-title-right -->
                    </div>
                    <!-- /.row -->
                </div>
                <!-- /.container -->
            </div>
            <!-- /.page-title -->
            <!-- =================================== -->
            <div class="container">
                <div class="row">
					<div class="col-md-12 widget-holder">
						<div class="widget-bg">
							<div class="widget-heading clearfix">
								<h5>View Listing
								
								</h5>
							</div>
							<!-- /.widget-heading -->
							<div class="widget-body clearfix">
								<form id="profile_changes">
									{{ csrf_field()}}
									<div class="row">
										<div class="col-lg-6">
											<div class="list_view">
												<h4>CREATED BY: <span>Robert Downy</span></h4>
											</div>
										</div>
										<div class="col-lg-6">
										<div class="list_view">
											<h4>BUSINESS NAME : <span>The Tipsy Cow, Madison, WI</span></h4>
										</div>
										</div>
									</div>
								<div class="row">
									<div class="col-lg-6">
										<div class="list_view">
												<h4>CATEGORY: <span>Hospital</span></h4>
											</div>
									</div>
									<div class="col-lg-6">
										<div class="list_view">
											<h4>TAGS : <span>Food, Travelling</span></h4>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-12">
										<div class="list_view">
											<h4>DESCRIPTION :
											<span>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</span></h4>
											
										</div>
									</div>
								</div>
								<div class="row">
								
									<div class="col-md-12 widget-holder mt-0">
									<div class="widget-heading clearfix pl-0">
                                    <div class="list_view">
											<h4 class="mt-0">OPENING HOURS</h4>
											</div>
                                </div>
                            <div class="widget-bg-2">
                              
                                <!-- /.widget-heading -->
                                <div class="widget-body clearfix">
                                    
                                    <table class="tablesaw color-table table-hover table" data-tablesaw-mode="swipe" data-tablesaw-sortable data-tablesaw-sortable-switch data-tablesaw-minimap data-tablesaw-mode-switch>
                                        <thead>
                                            <tr class="bg-primary">
                                                <th scope="col" data-tablesaw-sortable-col data-tablesaw-priority="persist">Days</th>
                                                <th scope="col" data-tablesaw-sortable-col data-tablesaw-sortable-default-col data-tablesaw-priority="3">Opening Time</th>
                                                <th scope="col" data-tablesaw-sortable-col data-tablesaw-priority="2">Closing Time</th>
                                               
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td class="title">Sunday</td>
                                                <td>10:00 AM</td>
                                                <td>9:30 PM</td>
                                              
                                            </tr>
                                            <tr>
                                                <td class="title">Monday</td>
                                                <td>10:00 AM</td>
                                                <td>9:30 PM</td>
                                              
                                            </tr>
                                            <tr>
                                                <td class="title">Tuesday</td>
                                                <td>10:00 AM</td>
                                                <td>9:30 PM</td>
                                               
                                            </tr>
                                            <tr>
                                                <td class="title">Wednesday</td>
                                                <td>10:00 AM</td>
                                                <td>9:30 PM</td>
                                              
                                            </tr>
                                            <tr>
                                                <td class="title">Thursday</td>
                                                <td>10:00 AM</td>
                                                <td>9:30 PM</td>
                                               
                                            </tr>
                                            <tr>
                                                <td class="title">Friday</td>
                                                <td>10:00 AM</td>
                                                <td>9:30 PM</td>
                                               
                                            </tr>
                                            <tr>
                                                <td class="title">Saturday</td>
                                                <td>10:00 AM</td>
                                                <td>9:30 PM</td>
                                                
                                            </tr>
                                            
                                           
                                        </tbody>
                                    </table>
                                </div>
                                <!-- /.widget-body -->
                            </div>
                            <!-- /.widget-bg -->
                        </div>
                        
								
								</div>
								<div class="row">
									<div class="col-lg-12">
										<h4 class="dobl-brdr mt-2">Contact Information</h4>
									</div>
								</div>
								
								<div class="row">
									<div class="col-lg-6">
										<div class="list_view">
											<h4>ADDRESS : <span>House No. 12121</span></h4>
										</div>
									</div>
									<div class="col-lg-6">
										<div class="list_view">
											<h4>CITY : <span>Ludhiana</span></h4>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-6">
										<div class="list_view">
											<h4>STATE : <span>Punjab</span></h4>
										</div>
									</div>
									<div class="col-lg-6">
										<div class="list_view">
											<h4>PHONE NO. : <span>01223-89679</span></h4>
										</div>
									</div>
								</div>
								
								<div class="row">
									<div class="col-lg-6">
										<div class="list_view">
											<h4>EMAIL : <span>info@example.com</span></h4>
										</div>
									</div>
									<div class="col-lg-6">
										<div class="list_view">
											<h4>WEBSITE : <span>www.example.com</span></h4>
										</div>
									</div>
								</div>
								
					<div class="row">
					
					
												<div class="col-lg-12">
												<div class="list_view">
											<h4 class="mb-3">LOCATION ON MAP </h4>
										</div>
												
													<div class="map-container">
                                          <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3153.5755969364104!2d-122.45284058544394!3d37.77654837975904!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8085874c16fa329f%3A0x48adaf3dfc9ffca6!2s2130+Fulton+St%2C+San+Francisco%2C+CA+94117%2C+USA!5e0!3m2!1sen!2sin!4v1563872542038!5m2!1sen!2sin" width="600" height="450" frameborder="0" style="border:0" allowfullscreen=""></iframe>
                                       </div>
												</div>
											</div>

<div class="row preview-images-zone mt-3 ui-sortable">
		<div class="col-lg-12"><div class="list_view">
											<h4 class="mb-3">IMAGES SELECTED </h4>
										</div></div>
        <div class="col-lg-3 preview-image preview-show-1 ui-sortable-handle">
            
            <div class="image-zone"><img id="pro-img-1" src="{{URL('UserAsset/images/list1.jpg')}}"></div>
         
        </div>
        <div class="col-lg-3 preview-image preview-show-2 ui-sortable-handle">
            
             <div class="image-zone"><img id="pro-img-2" src="{{URL('UserAsset/images/list2.jpg')}}"></div>
            
        </div>
        <div class="col-lg-3 preview-image preview-show-3 ui-sortable-handle">
            
			 <div class="image-zone"><img id="pro-img-3" src="{{URL('UserAsset/images/list3.jpg')}}"></div>
            
        </div>
    </div>
	
	<div class="row">
												<div class="col-lg-12 mt-3">
													<div class="form-actions btn-list">
														<!--<button class="btn btn-primary" type="submit">Save Changes</button>-->
														<a href="http://localhost/sabi/admin/users" class="btn btn-warning">Go Back To Edit</a>
															<span id="pass-error" class="text-danger"></span>
													</div>
												</div>
											</div>
	

									
									
								</form>
							</div>
							<!-- /.widget-body -->
						</div>
						<!-- /.widget-bg -->
					</div>
               </div>
            </div>
            <!-- /.container -->
        </main>
@endsection('body')
@section('script')
<script type="text/javascript">
      $(".livesearch").chosen();
$('.timepicker').timepicker({
        defaultTime: false
  });
       
    </script>
	<script>
$(document).ready(function(){
	$(".addCF").click(function(){
		
		$("#customFields").append('<div class="customFields row"><div class="col-md-4"><div class="form-group"><select class="form-control"><option>Select Day</option><option>Monday</option><option>Tuesday</option><option>Wednesday</option><option>Thursday</option><option>Friday</option><option>Saturday</option><option>Sunday</option></select></div></div><div class="col-md-3"><div class="form-group"><div class="input-group"><input type="text" class="input-group date timepicker form-control" placeholder="Opening Hour" /><span class="input-group-addon"><span class="fa fa-clock-o"></span></span></div></div></div><div class="col-md-3"><div class="form-group"><div class="input-group"><input type="text" class="input-group date timepicker form-control" placeholder="Closing Hour" /><span class="input-group-addon"><span class="fa fa-clock-o"></span></span></div></div></div><div class="col-md-2"><div class="form-group"><a href="javascript:void(0);" class="btn add-row remCF"><i class="fa fa-minus"</a></div></div></div>');
	 $('.timepicker').timepicker({
        defaultTime: false
  });
  $(".livesearch").chosen();

	});
    $("#customFields").on('click','.remCF',function(){
        $(this).parent().parent().parent().remove();
    });
});

$(document).ready(function() {
    document.getElementById('pro-image').addEventListener('change', readImage, false);
    
    $( ".preview-images-zone" ).sortable();
    
    $(document).on('click', '.image-cancel', function() {
        let no = $(this).data('no');
        $(".preview-image.preview-show-"+no).remove();
    });
});



var num = 4;
function readImage() {
    if (window.File && window.FileList && window.FileReader) {
        var files = event.target.files; //FileList object
        var output = $(".preview-images-zone");

        for (let i = 0; i < files.length; i++) {
            var file = files[i];
            if (!file.type.match('image')) continue;
            
            var picReader = new FileReader();
            
            picReader.addEventListener('load', function (event) {
                var picFile = event.target;
                var html =  '<div class="col-lg-3 preview-image preview-show-' + num + '">' +
                            '<div class="image-cancel" data-no="' + num + '">x</div>' +
                            '<div class="image-zone"><img id="pro-img-' + num + '" src="' + picFile.result + '"></div>' +
                            '</div>';

                output.append(html);
                num = num + 1;
            });

            picReader.readAsDataURL(file);
        }
        $("#pro-image").val('');
    } else {
        console.log('Browser not support');
    }
}


</script>
@endsection('script')