@extends('admin.master')
@section('body')
        <main class="main-wrapper clearfix">
            <!-- Page Title Area -->
            <div class="page-title">
                <div class="container">
                    <div class="row">
                        <div class="page-title-left">
                            <h6 class="page-title-heading mr-0 mr-r-5">Notifications</h6>
                        </div>
                        <!-- /.page-title-left -->
                        <div class="page-title-right d-none d-sm-inline-flex align-items-center">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="{{route('adm.admin')}}">Home</a>
                                </li>
                                <li class="breadcrumb-item active">Notifications</li>
                            </ol>
                        </div>
                        <!-- /.page-title-right -->
                    </div>
                    <!-- /.row -->
                </div>
                <!-- /.container -->
            </div>
            <!-- /.page-title -->
            <!-- =================================== -->
            <div class="container">
                <div class="row">
					<div class="col-md-12 widget-holder">
						<div class="widget-bg">
							<div class="widget-heading clearfix">
								<h5>Notifications				
								</h5>
							</div>
							<!-- /.widget-heading -->
							<div class="widget-body clearfix">
								<ul class="widget-user-activities list-noti">
                                    <li class="media">
                                        <figure class="thumb-xs2">
                                            <a href="#">
                                                <img class="rounded-circle" src="assets/demo/users/4.jpg" alt="">
                                            </a>
                                        </figure>
                                        <div class="media-body"><a href="#" class="single-user-name">Joseph S. Ferland</a>  
										<small>Lorem ipsum dolor sit amet, consectetur adipiscing elit</small>
                                         <span class="float-right tct-sa"> <i class="fa fa-clock-o"></i> 4 hours ago </span>
                                        </div>
                                        <!-- /.media-body -->
                                    </li>
                                    <!-- /.media -->
                                    <li class="media">
                                        <figure class="thumb-xs2">
                                            <a href="#">
                                                <img class="rounded-circle" src="assets/demo/users/2.jpg" alt="">
                                            </a>
                                        </figure>
                                        <div class="media-body"><a href="#" class="single-user-name">Sebastion Mechel</a>  
										<small>Sed ut perspiciatis unde omnis iste natus error sit</small>
                                        <span class="float-right tct-sa"> <i class="fa fa-clock-o"></i> 12 hours ago </span> 
                                        </div>
                                        <!-- /.media-body -->
                                    </li>
                                    <!-- /.media -->
                                    <li class="media">
                                        <figure class="thumb-xs2">
                                            <a href="#">
                                                <img class="rounded-circle" src="assets/demo/users/3.jpg" alt="">
                                            </a>
                                        </figure>
                                        <div class="media-body"><a href="#" class="single-user-name">Milosz Pasternak</a>  
										<small>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis</small>
                                        <span class="float-right tct-sa"> <i class="fa fa-clock-o"></i> 2 days ago </span>   
                                        </div>
                                        <!-- /.media-body -->
                                    </li>
                                    <!-- /.media -->
                                    <li class="media">
                                        <figure class="thumb-xs2">
                                            <a href="#">
                                                <img class="rounded-circle" src="assets/demo/users/1.jpg" alt="">
                                            </a>
                                        </figure>
                                        <div class="media-body"><a href="#" class="single-user-name">Betty Smith</a>  
										<small>Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis</small>
                                        <span class="float-right tct-sa"> <i class="fa fa-clock-o"></i> 12 days ago </span>   
                                        </div>
                                        <!-- /.media-body -->
                                    </li>
                                    <!-- /.media -->
                                    <li class="media">
                                        <figure class="thumb-xs2">
                                            <a href="#">
                                                <img class="rounded-circle" src="assets/demo/users/5.jpg" alt="">
                                            </a>
                                        </figure>
                                        <div class="media-body"><a href="#" class="single-user-name">Edgar J. Crawford</a>  
										<small>Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam</small>
                                        <span class="float-right tct-sa"> <i class="fa fa-clock-o"></i> 1 month ago </span>  
                                        </div>
                                        <!-- /.media-body -->
                                    </li>
                                    <!-- /.media -->
                                </ul>
							</div>
							<!-- /.widget-body -->
						</div>
						<!-- /.widget-bg -->
					</div>
               </div>
            </div>
            <!-- /.container -->
        </main>
        <!-- /.main-wrappper -->
       
    @endsection('body')